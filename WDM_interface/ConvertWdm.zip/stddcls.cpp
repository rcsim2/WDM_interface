// stddcls.cpp -- Precompiled header stub for WDM driver
// Produced by Walt Oney's driver wizard

#include "stddcls.h"
