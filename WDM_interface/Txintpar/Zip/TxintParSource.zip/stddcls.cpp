// stddcls.cpp -- Precompiled header stub for WDM driver

#include "stddcls.h"
